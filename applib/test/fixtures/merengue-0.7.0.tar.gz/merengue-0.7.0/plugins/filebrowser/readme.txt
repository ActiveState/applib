================
filebrowser plugin
================


``filebrowser`` is a Merengue plugin based in ``webfs`` a Django application for integrate a document and file multirepository
in your web.
